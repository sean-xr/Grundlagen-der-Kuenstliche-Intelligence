import numpy as np
from field_var import *


def generate_knowledge(chessboard_array):
    """
    Initialize the knowledge base, by adding statements describing
    the initial state of the chessboard, as well as the rules concerning the
    danger fields.
    
    You can use the functions Queen(x,y), Pawn(x,y), and Danger(x,y) to
    produce the statements Qxy, Pxy, and Dxy, if x and y are integers.
    
    Input: np.ndarray 2-D array, where each field
            contains either 'Q', 'P', 'D' or '0'
            
    Output: A list kb of logical sentences that will be added to
             the knowledge base
    """

    chessboard_size = len(chessboard_array)
    kb = []
    all_fields = []

    for x in range(chessboard_size):
        for y in range(chessboard_size):
            all_fields.append((x, y))

    for field in all_fields:
        benchmark = 0
        if chessboard_array[field[0]][field[1]] == 'Q':
            kb.append(Queen(field[0], field[1]))
            continue
        elif chessboard_array[field[0]][field[1]] == 'P':
            kb.append(Pawn(field[0], field[1]))
            continue
        elif chessboard_array[field[0]][field[1]] == 'D':
            kb.append(Danger(field[0], field[1]))
            continue
        else:# consider the same row left
            for i in range(field[0]+1):
                if chessboard_array[field[0] - i][field[1]] == 'Q':
                    benchmark = 'danger'
                    break
                elif chessboard_array[field[0] - i][field[1]] == 'P':
                    benchmark = 'pawn'
                    break
            if benchmark != 'danger':  # consider the same row right
                for i in range(chessboard_size - field[0]):
                    if chessboard_array[field[0] + i][field[1]] == 'Q':
                        benchmark = 'danger'
                        break
                    elif chessboard_array[field[0] + i][field[1]] == 'P':
                        benchmark = 'pawn'
                        break
                if benchmark != 'danger':  # consider the same column up
                    for i in range(field[1] + 1):
                        if chessboard_array[field[0]][field[1] - i] == 'Q':
                            benchmark = 'danger'
                            break
                        elif chessboard_array[field[0]][field[1] - i] == 'P':
                            benchmark = 'pawn'
                            break
                    if benchmark != 'danger':  # consider the same column down
                        for i in range(chessboard_size - field[1]):
                            if chessboard_array[field[0]][field[1] + i] == 'Q':
                                benchmark = 'danger'
                                break
                            elif chessboard_array[field[0]][field[1] + i] == 'P':
                                benchmark = 'pawn'
                                break
                        if benchmark != 'danger':  # consider the same 135 degree up
                            for i in range(min(field[0]+1, field[1]+1)):
                                # if np.minimum(field[0] - i, field[1] - i) < 0:
                                #     break
                                if chessboard_array[field[0] - i][field[1] - i] == 'Q':
                                    benchmark = 'danger'
                                    break
                                elif chessboard_array[field[0] - i][field[1] - i] == 'P':
                                    benchmark = 'pawn'
                                    break
                            if benchmark != 'danger':  # consider the same 135 degree down
                                for i in range(min(chessboard_size-field[0], chessboard_size-field[1])):
                                    # if np.maximum(field[0] + i, field[1] + i) > (chessboard_size - 1):
                                    #     break
                                    if chessboard_array[field[0] + i][field[1] + i] == 'Q':
                                        benchmark = 'danger'
                                        break
                                    elif chessboard_array[field[0] + i][field[1] + i] == 'P':
                                        benchmark = 'pawn'
                                        break
                                if benchmark != 'danger':  # consider the 45 degree up
                                    for i in range(min(field[1]+1, chessboard_size-field[0])):
                                        # if np.maximum(field[0] + i, field[1] - i) > (chessboard_size - 1) or np.minimum(
                                        #         field[0] + i, field[1] - i) < 0:
                                        #     break
                                        if chessboard_array[field[0] + i][field[1] - i] == 'Q':
                                            benchmark = 'danger'
                                            break
                                        elif chessboard_array[field[0] + i][field[1] - i] == 'P':
                                            benchmark = 'pawn'
                                            break
                                    if benchmark != 'danger':  # consider the 45 degree down
                                        for i in range(min(field[0]+1, chessboard_size-field[1])):
                                            # if np.maximum(field[0] - i, field[1] + i) > (
                                            #         chessboard_size - 1) or np.minimum(field[0] - i, field[1] + i) < 0:
                                            #     break
                                            if chessboard_array[field[0] - i][field[1] + i] == 'Q':
                                                benchmark = 'danger'
                                                break
                                            elif chessboard_array[field[0] - i][field[1] + i] == 'P':
                                                benchmark = 'pawn'
                                                break
                                        if benchmark != 'danger':
                                            continue
                                        else:
                                            kb.append(Danger(field[0], field[1]))
                                    else:
                                        kb.append(Danger(field[0], field[1]))
                                else:
                                    kb.append(Danger(field[0], field[1]))
                            else:
                                kb.append(Danger(field[0], field[1]))
                        else:
                            kb.append(Danger(field[0], field[1]))
                    else:
                        kb.append(Danger(field[0], field[1]))
                else:
                    kb.append(Danger(field[0], field[1]))
            else:
                kb.append(Danger(field[0], field[1]))
    for field in all_fields:  # consider the same row left
        for j in range(field[0]+1):
            if chessboard_array[field[0]-j][field[1]] == 'P':
                break
            sentence1 = Queen(field[0], field[1])+'==>'+Danger(field[0]-j, field[1])
            kb.append(sentence1)
        for j in range(chessboard_size-field[0]):  # consider the same row right
            if chessboard_array[field[0]+j][field[1]] == 'P':
                break
            sentence2 = Queen(field[0], field[1])+'==>'+Danger(field[0]+j, field[1])
            kb.append(sentence2)
        for j in range(field[1]+1):  # consider the same column up
            if chessboard_array[field[0]][field[1]-j] == 'P':
                break
            sentence3 = Queen(field[0], field[1])+'==>'+Danger(field[0], field[1]-j)
            kb.append(sentence3)
        for j in range(chessboard_size-field[1]):  # consider the same column down
            if chessboard_array[field[0], field[1]+j] == 'P':
                break
            sentence4 = Queen(field[0], field[1])+'==>'+Danger(field[0], field[1]+j)
            kb.append(sentence4)
        for j in range(chessboard_size):  # consider the same 45(from the left) up
            if min(field[0]-j,field[1]-j) < 0:
                break
            elif chessboard_array[field[0]-j][field[1]-j] == 'P':
                break
            sentence5 = Queen(field[0], field[1])+'==>'+Danger(field[0]-j, field[1]-j)
            kb.append(sentence5)
        for j in range(chessboard_size):  # consider the same 45(from the left) down
            if max(field[0]+j, field[1]+j) > chessboard_size-1:
                break
            elif chessboard_array[field[0]+j][field[1]+j] == 'P':
                break
            sentence6 = Queen(field[0], field[1])+'==>'+Danger(field[0]+j, field[1]+j)
            kb.append(sentence6)
        for j in range(chessboard_size):  # consider the same 135(from the left) up
            if max(field[0]+j, field[1]-j) > chessboard_size-1 or min(field[0]+j, field[1]-j) < 0:
                break
            elif chessboard_array[field[0]+j][field[1]-j] == 'P':
                break
            sentence7 = Queen(field[0], field[1])+'==>'+Danger(field[0]+j, field[1]-j)
            kb.append(sentence7)
        for j in range(chessboard_size):  # consider the same 135(from the left) down
            if max(field[0]-j, field[1]+j) > chessboard_size-1 or min(field[0]-j, field[1]+j) < 0:
                break
            elif chessboard_array[field[0]-j][field[1]+j] == 'P': # consider the same 135 up
                break
            sentence8 = Queen(field[0], field[1])+'==>'+Danger(field[0]-j, field[1]+j)
            kb.append(sentence8)
    # for field in all_fields:
    #     benchmark1 = 0
    #     sentence = ''
    #     if chessboard_array[field[0]][field[1]] == 'Q':
    #         sentence = Queen(field[0]][field[1])
    #         kb.tell(expr(sentence))
    #         continue
    #     elif chessboard_array[field[0]][field[1]] == 'P':
    #         sentence = Pawn(field[0])(field[1])
    #         kb.tell(expr(sentence))
    #         continue
    #     elif chessboard_array[field[0]][field[1]] == 'D':
    #         kb.append(Danger(field[0], field[1]))
    #         continue
    #     else:
    return kb
